function Data=ProblemData()          

nF=15;    % Number of Facilities
nP=3;    % Number of Periods
% Solution Length for each period
MatrixRank=ceil(sqrt(nF));
SolLength=MatrixRank^2;

TW=30;
TL=20;

% Flow Matrix: randi([0 10],nF)*nP 
F=cell(3,1);
F{1}=zeros(15);
F{1}(1,3)=25;  F{1}(3,5)=25; F{1}(5,14)=25;  F{1}(6,13)=25; F{1}(6,14)=25;
F{1}(13,15)=25;

F{2}=zeros(15);
F{2}(1,2)=10; F{2}(2,5)=15; F{2}(2,8)=10;  F{2}(2,12)=15; F{2}(3,5)=20;
F{2}(3,8)=20; F{2}(4,5)=10; F{2}(4,8)=10;  F{2}(5,7)=10; F{2}(7,11)=20;
F{2}(7,12)=25; F{2}(7,15)=35;  F{2}(8,11)=20; F{2}(12,15)=10;

F{3}=zeros(15);
F{3}(1,2)=25; F{3}(2,4)=15;  F{3}(2,5)=10; F{3}(2,8)=10; F{3}(2,12)=10;
F{3}(3,5)=5; F{3}(3,8)=5; F{3}(4,5)=10; F{3}(4,8)=10; F{3}(4,10)=15; 
F{3}(5,7)=10; F{3}(5,9)=15; F{3}(5,11)=15; F{3}(7,9)=15; F{3}(7,10)=15;
F{3}(7,11)=5;F{3}(7,12)=20; F{3}(7,15)=15; F{3}(8,11)=5; F{3}(11,15)=15;F{3}(12,15)=10;    


 % Areas of The Departments in Each period randi([4 15]), SolLength*nP
 A=[45 35 62 42 33 28 35 35 30 35 36 22 38 42 82 0
    35 45 54 45 32 14 55 48 28 33 44 30 24 28 85 0
    39 50 45 50 33 13 52 40 34 40 43 29 22 27 83 0];
 
 % Rearrangrment Cost : randi([10 30],nF). Each Department has  fixed
 % Rearrangement cost in all periods
  R=[5 3 1 3 1 3 1 1 1 1 1 1 1 1 4 ];
  
  % Adjacency Requirement Matrix: randi([0 5],nF)*nP. 
  %it shoul be a symmetric matrixd
  AV={[0   4     0     3     4     0     0     4     0     2     3     0     0     2     2
     1     0     2     4     3     0     0     3     1     3     0     0     5     3     2
     2     5     0     3     3     3     3     4     1     0     1     0     4     0     2
     2     0     5     0     4     2     1     2     3     5     4     0     3     2     3
     4     4     1     0     0     5     3     1     0     1     4     1     1     0     4
     4     4     0     4     4     0     4     0     2     1     0     1     0     4     2
     0     3     1     5     1     4     0     4     0     4     0     1     3     5     2
     1     1     2     3     4     0     4     0     0     2     0     1     5     2     0
     2     3     0     0     3     0     1     2     0     4     0     1     1     4     0
     0     1     5     4     2     0     4     3     1     0     2     1     1     1     1
     3     0     1     2     0     4     5     1     3     1     0     5     2     3     1
     2     1     1     1     4     5     5     3     5     0     4     0     0     4     3
     1     5     0     4     2     4     0     2     2     4     3     3     0     3     5
     1     0     1     0     3     0     2     0     4     2     0     1     2     0     5
     5     1     0     0     4     4     2     4     4     2     3     1     5     1     0]
     
     
    [0     3     1     4     0     5     3     1     5     4     4     5     4     1     5
     4     0     1     4     5     4     2     4     3     2     5     5     5     3     5
     4     0     0     4     3     3     3     5     0     3     2     4     0     5     4
     4     5     5     0     2     1     0     0     1     1     5     0     1     3     3
     4     3     3     2     0     5     5     3     1     1     2     2     0     0     2
     0     4     5     2     1     0     4     0     0     4     5     4     2     2     5
     4     0     0     4     3     5     0     4     0     3     2     4     1     0     0
     2     4     5     1     3     1     4     0     3     2     2     1     5     3     4
     1     4     4     4     2     2     2     0     0     3     1     1     0     2     3
     0     0     3     4     0     0     3     5     2     0     0     4     0     5     4
     4     3     2     5     0     3     3     0     2     3     0     2     3     4     2
     1     1     1     3     2     1     3     4     5     3     4     0     4     2     4
     0     3     4     3     1     0     1     4     5     3     4     1     0     5     5
     3     2     1     5     4     4     1     3     4     3     4     1     1     0     1
     5     2     0     2     2     2     2     5     5     0     0     4     2     2     0] 
     
     [0     2     4     1     1     5     4     4     3     3     4     0     4     2     3
     3     0     0     4     1     0     5     0     0     0     5     2     5     2     0
     1     1     0     3     0     1     2     0     2     2     5     1     4     3     0
     3     1     0     0     2     0     2     3     3     4     3     4     0     3     3
     2     4     3     2     0     1     3     1     3     5     3     1     4     5     5
     4     3     2     3     5     0     1     5     2     4     0     5     2     4     5
     2     3     4     4     0     4     0     5     5     2     5     4     2     2     3
     2     3     3     0     5     5     3     0     4     4     2     2     0     4     5
     4     0     2     0     2     3     3     4     0     2     1     2     4     0     3
     5     2     5     5     0     0     1     5     2     0     5     4     1     0     3
     1     2     2     3     2     5     0     3     3     5     0     5     1     0     1
     5     1     2     1     4     4     2     5     5     5     5     0     2     0     2
     4     4     5     2     4     1     2     5     5     2     1     3     0     1     2
     5     5     0     0     3     3     4     3     4     2     4     1     3     0     0
     0     1     5     1     4     5     4     4     1     1     3     2     3     0     0]};
 
 
 % Optimal Desired Aspect Ractio. Optimal Gamma
 GammaOpt=3;
 % Ratio Tolerance. Tau
 Tau=2;
 % Ratio Satisfaction Reward
 RSR=40;
 
 % Number of cuts Need
 cn=floor(sqrt(nF));
 
 
 Data.F=F;      Data.cn=cn;
 Data.nP=nP;     Data.TW=TW;       Data.TL=TL;
 Data.nF=nF;
 Data.SolLength=SolLength;
 Data.Areas=A;
 Data.R=R;
 Data.AV=AV;
 Data.GammaOpt=GammaOpt;
 Data.Tau=Tau;
 Data.RSR=RSR;
















