function PlotCosts(pop)

    Costs=[pop.Cost];
    
    plot(Costs(2,:),Costs(1,:),'r*','MarkerSize',8);
    title('Pareto Front');
    xlabel('1st Objective');
    ylabel('2nd Objective');
    grid on;

end