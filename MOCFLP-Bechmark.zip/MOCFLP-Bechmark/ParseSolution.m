function Period=ParseSolution(x,MainCuts)

Data=ProblemData();
 nF=Data.nF;   SolLength=Data.SolLength;  nP=Data.nP; cn=Data.cn;
 MainA=Data.Areas'; %R=Data.R;AV=Data.AV;   AF=Data.AF; GammaOpt=Data.GammaOpt;
% Tau=Data.Tau;     RSR=Data.RSR;F=Data.F;   

% x=[4 6 5 1 7 2 8 9 3    3 2 7 9 4 1 8 5 6   1 3 7 9 5 2 6 8 4];
% MainCuts=[1 0,1 0 1 0]; 
pp=1; 
Period=repmat(struct('C',[],'W',[],'L',[],'d',[]),1,nP);

TW=Data.TW;TL=Data.TL;

ii2=1;

for i2=1:SolLength:numel(x)
    
    d=x(i2:i2+SolLength-1); 
    cuts=MainCuts(ii2:ii2+cn-1);
    A=MainA(i2:i2+SolLength-1);
    A=A(d);
    d(d>nF)=0;
    
    [C,W,L]=GetCoordinates(d,A,cuts,TL,TW);
    [Distance AF]=GetDistance(C,TL,TW);
     
    Period(pp).C=C;   Period(pp).W=W;   Period(pp).L=L;         
    Period(pp).d=Distance; Period(pp).AF=AF;
    pp=pp+1;
    
    ii2=ii2+cn;
end


% d=[8 10 0 0 0 2 6 3 7 4 5  0 0 1 0 9];
% A=[10 18 0 0 0 6 6 6 10 4 12 0 0 10 0 8];

%% Determine Centroid, Width and Length of Departments
function [C W L]=GetCoordinates(d,A,cuts,TL,TW)
    
    
DM=reshape(d,sqrt(numel(d)),[])';         
AM=reshape(A,sqrt(numel(d)),[])';
x0=0;y0=0;  % Center Coordinate of the Floor


% Facilities Centroid, Width and Length
C=cell(nF,1);
W=zeros(1,nF);
L=zeros(1,nF);


for i=cuts
    
    if size(DM,1)==2
       if i==1
        
        b1=DM(:,1);  a1=AM(:,1); 
        DM(:,1)=[]; AM(:,1)=[];
        b2=DM(:,1); a2=AM(:,1);
       % DM(:,1)=[]; AM(:,1)=[];
        
%         x0=sum(a1)/TL+x0;
        b1=b1(b1~=0);a1=a1(a1~=0);
        b2=b2(b2~=0);a2=a2(a2~=0);
        
        for j=1:numel(b1)           
           W(b1(j))=sum(a1)/TL;
           L(b1(j))=a1(j)/W(b1(j));
           C{b1(j)}=[x0+W(b1(j))/2,y0+sum(L(b1(1:j-1)))+L(b1(j))/2]; 
          
        end
        x0=x0+sum(a1)/TL;               
        
        for j=1:numel(b2)
           W(b2(j))=sum(a2)/TL;
           L(b2(j))=a2(j)/W(b2(j));
           C{b2(j)}=[x0+W(b2(j))/2,y0+sum(L(b2(1:j-1)))+L(b2(j))/2];
%            L(b2(j))=sum(a2)/TW;
%            W(b2(j))=a2(j)/L(b2(j));
%            C{b2(j)}=[x0+sum(W(b2(1:j-1)))+W(b2(j))/2,y0+L(b2(j))/2];
        end 

       
    else
        b2=DM(1,:); a2=AM(1,:);
        DM(1,:)=[]; AM(1,:)=[];
        b1=DM(1,:);  a1=AM(1,:); 
       % DM(1,:)=[]; AM(1,:)=[];
        
        b1=b1(b1~=0);a1=a1(a1~=0);
        b2=b2(b2~=0);a2=a2(a2~=0);
                
        for j=1:numel(b2)
           
           L(b2(j))=sum(a2)/TW;
           W(b2(j))=a2(j)/L(b2(j));
           C{b2(j)}=[x0+sum(W(b2(1:j-1)))+W(b2(j))/2,y0+L(b2(j))/2];
        end 
        
        y0=y0+sum(a2)/TW;
        
         for j=1:numel(b1)
             
           L(b1(j))=sum(a1)/TW;
           W(b1(j))=a1(j)/L(b1(j));
           C{b1(j)}=[x0+sum(W(b1(1:j-1)))+W(b1(j))/2,y0+L(b1(j))/2];
           
%            W(b1(j))=sum(a1)/TW;
%            L(b1(j))=a1(j)/W(b1(j));
%            C{b1(j)}=[x0/2,y0+sum(L(b1(1:j-1)))+L(b1(j))/2]; 
          
         end
       end 
       break;
        
    end
    
    if i==1
        
        b1=DM(:,1);  a1=AM(:,1); 
        DM(:,1)=[]; AM(:,1)=[];
        b2=DM(1,:); a2=AM(1,:);
        DM(1,:)=[]; AM(1,:)=[];
        
%         x0=sum(a1)/TL+x0;
        b1=b1(b1~=0);a1=a1(a1~=0);
        b2=b2(b2~=0);a2=a2(a2~=0);
        
        for j=1:numel(b1)           
           W(b1(j))=sum(a1)/TL;
           L(b1(j))=a1(j)/W(b1(j));
           C{b1(j)}=[x0+W(b1(j))/2,y0+sum(L(b1(1:j-1)))+L(b1(j))/2]; 
          
        end
        x0=x0+sum(a1)/TL;        
        TW=TW-sum(a1)/TL;        
        
        for j=1:numel(b2)
           
           L(b2(j))=sum(a2)/TW;
           W(b2(j))=a2(j)/L(b2(j));
           C{b2(j)}=[x0+sum(W(b2(1:j-1)))+W(b2(j))/2,y0+L(b2(j))/2];
        end 
        y0=y0+sum(a2)/TW;
        TL=TL-sum(a2)/TW;
       
    else
        b2=DM(1,:); a2=AM(1,:);
        DM(1,:)=[]; AM(1,:)=[];
        b1=DM(:,1);  a1=AM(:,1); 
        DM(:,1)=[]; AM(:,1)=[];
        
        b1=b1(b1~=0);a1=a1(a1~=0);
        b2=b2(b2~=0);a2=a2(a2~=0);
                
        for j=1:numel(b2)
           
           L(b2(j))=sum(a2)/TW;
           W(b2(j))=a2(j)/L(b2(j));
           C{b2(j)}=[x0+sum(W(b2(1:j-1)))+W(b2(j))/2,y0+L(b2(j))/2];
        end 
        
        y0=y0+sum(a2)/TW;
        TL=TL-sum(a2)/TW;
        
         for j=1:numel(b1)           
           W(b1(j))=sum(a1)/TL;
           L(b1(j))=a1(j)/W(b1(j));
           C{b1(j)}=[x0+W(b1(j))/2,y0+sum(L(b1(1:j-1)))+L(b1(j))/2]; 
          
         end
        x0=x0+sum(a1)/TL;        
        TW=TW-sum(a1)/TL;
    end       
       
 
end
end

%% Detemine the Distance Between Departments
function [Distance AF]=GetDistance(C,TL,TW)  
    Distance=zeros(nF);AF=zeros(nF);
    Intervals=[(TW+TL)/6 2*(TW+TL)/6 3*(TW+TL)/6 4*(TW+TL)/6 5*(TW+TL)/6 6*(TW+TL)/6] ;
    for ii=1:nF-1
        
       for jj=ii+1:nF
           Distance(ii,jj)=abs(C{ii}(1)-C{jj}(1))+abs(C{ii}(2)-C{jj}(2));
           Distance(jj,ii)=Distance(ii,jj);
           
           i5=0; % Start interval
              while(Distance(ii,jj)>=Intervals(i5+1)) 
                 i5 = i5 + 1;
              end    
               AF(ii,jj)=1-i5*0.2; AF(jj,ii)=AF(ii,jj);
           
       end
                
    end
    
end


end







