% Mutation Operation
function [Position Cuts]=Mutation(Position,Cuts,Data)

nP=Data.nP;    SolLength=Data.SolLength; cn=Data.cn;

slice=0; cnslice=0;  

for i=1:nP
    c=randsample(SolLength,2);
    r=randsample(cn,1); c1=Cuts(cnslice+1:cnslice+cn);
    c1(r)=abs(c1(r)-1); Cuts(cnslice+1:cnslice+cn)=c1;
    
    s1=Position(slice+1:slice+SolLength);
    s1([c(1) c(2)])=s1([c(2) c(1)]);
    Position(slice+1:slice+SolLength)=s1;
    
    
    slice=slice+SolLength;
    cnslice=cnslice+cn;
    
end






