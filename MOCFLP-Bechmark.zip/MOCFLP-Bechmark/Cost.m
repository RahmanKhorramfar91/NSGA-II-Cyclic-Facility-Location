function cost=Cost(Position,Cuts,Data)

nF=Data.nF;  nP=Data.nP;
R=Data.R;AV=Data.AV;  GammaOpt=Data.GammaOpt;
Tau=Data.Tau;     RSR=Data.RSR;
Flow=Data.F;   
F1=0;  F2=0;  F3=0;  F4=0;
Period=ParseSolution(Position,Cuts);
%% Calcualtiong the Objectives Parts
for t=1:nP
    
   W=Period(t).W;
   L=Period(t).L;
   d=Period(t).d;
   AF=Period(t).AF;
   AValue=AV{t};
   f=Flow{t};
   
   for i=1:nF       
       
       for j=i+1:nF 
           F1=d(i,j)*f(i,j)+d(j,i)*f(j,i)+F1;                      
           F3=2*AValue(i,j)*AF(i,j)+F3;
       end
                    
   end   
       Gamma=max(L,W)./min(L,W);
       dev=(Tau-abs(Gamma-GammaOpt))/Tau;
       F4=F4+sum(dev.*RSR); 
       
     if t>1
         
         for i=1:nF
            if Period(t-1).L(i)~=Period(t).L(i) || Period(t-1).W(i)~=Period(t).W(i) || Period(t-1).C{i}(1)~=Period(t).C{i}(1) ||  Period(t-1).C{i}(2)~=Period(t).C{i}(2)
                F2=F2+R(i);                
                
            end                          
         end 
     end
     
     if t==nP
         
         for i=1:nF
            if Period(1).L(i)~=Period(t).L(i) || Period(1).W(i)~=Period(t).W(i) || Period(1).C{i}(1)~=Period(t).C{i}(1) ||  Period(1).C{i}(2)~=Period(t).C{i}(2)
                F2=F2+R(i);                                
            end                          
         end    
         
     end

end    
    
cost=[F1+F2 ; -(F3+F4)];















