clc;
clear;
close all;

%% Problem Definition

Data=ProblemData();

SolLength=Data.SolLength;
nP=Data.nP;
cn=Data.cn;

% Number of Objective Functions
nObj=2;


%% NSGA-II Parameters

MaxIt=1000;      % Maximum Number of Iterations

nPop=50;        % Population Size

pCrossover=0.7;                         % Crossover Percentage
nCrossover=2*round(pCrossover*nPop/2);  % Number of Parnets (Offsprings)

pMutation=0.4;                          % Mutation Percentage
nMutation=round(pMutation*nPop);        % Number of Mutants


%% Initialization

empty_individual.Position=[];
empty_individual.Cuts=[];
empty_individual.Cost=[];
empty_individual.Rank=[];
empty_individual.DominationSet=[];
empty_individual.DominatedCount=[];
empty_individual.CrowdingDistance=[];

pop=repmat(empty_individual,nPop,1);

for i=1:10
    f=randperm(SolLength); ff=round(rand(1,cn));
    for j=1:nP
       pop(i).Position=[pop(i).Position f];
       pop(i).Cuts=[pop(i).Cuts ff];
    end
    
    pop(i).Cost=Cost(pop(i).Position,pop(i).Cuts,Data);
    
end

for i=11:20
    f=randperm(SolLength); 
    for j=1:nP
       pop(i).Position=[pop(i).Position f];
       pop(i).Cuts=[pop(i).Cuts round(rand(1,cn))];
    end
    
    pop(i).Cost=Cost(pop(i).Position,pop(i).Cuts,Data);
    
end

for i=21:nPop
    
    for j=1:nP
       pop(i).Position=[pop(i).Position randperm(SolLength)];
       pop(i).Cuts=[pop(i).Cuts round(rand(1,cn))];
    end
    
    pop(i).Cost=Cost(pop(i).Position,pop(i).Cuts,Data);
    
end


% Non-Dominated Sorting
[pop F]=NonDominatedSorting(pop); %#ok<*NCOMMA>

% Calculate Crowding Distance
pop=CalcCrowdingDistance(pop,F);

% Sort Population
[pop F]=SortPopulation(pop);

tic;
%% NSGA-II Main Loop

for it=1:MaxIt
    
    % Crossover
    popc=repmat(empty_individual,nCrossover/2,2);
    for k=1:nCrossover/2
        
        i1=randi([1 nPop]);
        p1=pop(i1);
        
        i2=randi([1 nPop]);
        p2=pop(i2);
        
        [popc(k,1).Position popc(k,2).Position]=Crossover(p1.Position,p2.Position,Data);
        popc(k,1).Cuts=p1.Cuts;   popc(k,2).Cuts=p2.Cuts;
        
        popc(k,1).Cost=Cost(popc(k,1).Position, popc(k,1).Cuts,Data);
        popc(k,2).Cost=Cost(popc(k,2).Position,popc(k,1).Cuts,Data);
        
    end
    popc=popc(:);
    
    % Mutation
    popm=repmat(empty_individual,nMutation,1);
    for k=1:nMutation
        
        i=randi([1 nPop]);
        p=pop(i);
        
        [popm(k).Position popm(k).Cuts]=Mutation(p.Position,p.Cuts,Data);
        
        popm(k).Cost=Cost(popm(k).Position,popm(k).Cuts,Data);
        
    end
    
    % Merge
    pop=[pop
         popc
         popm]; %#ok<*AGROW>
     
    % Non-Dominated Sorting
    [pop F]=NonDominatedSorting(pop);

    % Calculate Crowding Distance
    pop=CalcCrowdingDistance(pop,F);

    % Sort Population
    [pop F]=SortPopulation(pop); %#ok<*ASGLU>
    
    % Truncate
    pop=pop(1:nPop);
    
    % Non-Dominated Sorting
    [pop F]=NonDominatedSorting(pop);

    % Calculate Crowding Distance
    pop=CalcCrowdingDistance(pop,F);

    % Sort Population
    [pop F]=SortPopulation(pop);
    
    % Store F1
    F1=pop(F{1});
    
    % Show Iteration Information
    disp(['Iteration ' num2str(it) ': Number of F1 Members = ' num2str(numel(F1))]);
    
    % Plot F1 Costs
    figure(1);
    PlotCosts(F1);
    
end
toc;
%% Results
sol=F1(1);

save('Front','F1');
PlotDeps(sol,Data);



%PlotDeps(sol,Data);





