% CrossOver Operator
function [child1 child2]=Crossover(str1,str2,Data)
% clc;clear;close all;
% Data=ProblemData();

nP=Data.nP;    SolLength=Data.SolLength; 

% str1=[3 5 1 2 4 6   1 4 3 2 5 6   2 6 3 1 5 4   5 6 3 1 2 4   5 1 4 6 2 3];
% str2=[6 4 2 1 3 5   5 4 2 1 3 6   6 4 2 3 5 1   4 6 1 3 5 2   4 5 1 3 6 2];
child1=zeros(size(str1));
child2=zeros(size(str1));

slice=0; 
for p=1:nP
   
    pos=randsample(SolLength,1);
    %pos=2;   
    s1=str1(slice+1:slice+SolLength);
    s2=str2(slice+1:slice+SolLength);
    
    s=zeros(1,SolLength);
    s(1:pos)=s1(1:pos); 
    
    s2(ismember(s2,s))=[];
    s(pos+1:end)=s2;
    
    child1(slice+1:slice+SolLength)=s;
    
    %%%%%%%%%%%%%5
    s1=str1(slice+1:slice+SolLength);
    s2=str2(slice+1:slice+SolLength);
    
    s=zeros(1,SolLength);
    s(1:pos)=s2(1:pos); 
    
    s1(ismember(s1,s))=[];
    s(pos+1:end)=s1;
    
    child2(slice+1:slice+SolLength)=s;
    %%%%%%%%%%%%
    
    slice=slice+SolLength;
    
end








