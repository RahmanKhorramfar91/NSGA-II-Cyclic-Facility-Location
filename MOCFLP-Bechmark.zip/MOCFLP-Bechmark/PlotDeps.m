function PlotDeps(sol,Data)
%Data=ProblemData();
nF=Data.nF;  nP=Data.nP;   TL=Data.TL; TW=Data.TW;
Period=ParseSolution(sol.Position,sol.Cuts);

Colors=hsv(nF);

for t=1:nP
    
    C=Period(t).C;
    C=cell2mat(C);
    C(:,2)=TL-C(:,2);
    W=Period(t).W;
    L=Period(t).L;
    
    figure(t+1);
    %set(gca,'YTick',[0 6 5 4 3 2 1]);   
    title(['Layout of Departments at Period ' num2str(t)]...
    ,'FontSize',12,'Color','Black');
    xlabel('X Axle','FontSize',11,'Color','Blue');
    ylabel('Y Axis','FontSize',11,'Color','Blue');
    hold on;
    axis([0 TW 0 TL])
    
   for i=1:nF
       
       c=Colors(i,:)*0.85;
       
       x=[C(i,1)-W(i)/2  C(i,1)-W(i)/2  C(i,1)+W(i)/2  C(i,1)+W(i)/2];
       y=[C(i,2)-L(i)/2  C(i,2)+L(i)/2  C(i,2)+L(i)/2  C(i,2)-L(i)/2];
       
       fill(x,y,c);
       hold on;
            
       xm=(x(1)+x(3))/2;
       ym=(y(1)+y(3))/2;
       text(xm,ym,['Dep. ' num2str(i)],'FontAngle','italic','HorizontalAlignment','center',...
                'VerticalAlignment','middle','FontSize',11,'FontWeight','bold');
       hold on
       
       
   end
    
    
end














